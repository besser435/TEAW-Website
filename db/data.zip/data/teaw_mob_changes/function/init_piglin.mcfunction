data merge entity @s {IsImmuneToZombification:1b}
tag @s add teawZombProcessed