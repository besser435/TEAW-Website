attribute @s minecraft:flying_speed base set 0.05
tag @s remove teawHappyGhastFast