attribute @s minecraft:flying_speed base set 0.1
tag @s add teawHappyGhastFast